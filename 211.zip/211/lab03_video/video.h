
#ifndef COURSE_H
#define COURSE_H
#include <iostream>
#include <string>


using namespace std;

class Video
{
    public:
	Video(string title, string url, string comment, double rating, int stars);
	
	void print();
        
	void print_stars();
        
    private:
	string m_title;
	string m_url;
	string m_comment;
	double m_rating;
	int m_stars;

}; 

#endif
