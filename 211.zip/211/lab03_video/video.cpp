#include <iostream>
#include <string>

#include "video.h"

Video::Video(string title, string url, string comment, double rating, int stars)
{
	m_title = title;
	m_url = url;
	m_comment = comment;
	m_rating = rating;
	m_stars = stars;

}

void Video::print()
{
	cout << m_title << ", " << m_url << ", " << m_comment << ", " << m_rating << ", ";
	while (m_stars > 0){
		cout << "*";
		m_stars--;}
	cout << endl;
}

