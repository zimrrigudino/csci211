// video.h
// Gudino, Zimrri
// zgudino
#ifndef COURSE_H
#define COURSE_H
#include <iostream>
#include <string>


using namespace std;

class Video
{
    public:
	Video(string title, string url, string comment, double length, int rating);
	void print();
	void print_rating();
	bool longer(Video *other);
	bool largerRating(Video *other);
	bool alphabetical(Video *other);
        
    private:
	string m_title;
	string m_url;
	string m_comment;
	double m_length;
	int m_rating;

}; 

#endif
