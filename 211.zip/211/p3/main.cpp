// main.cpp
// Gudino, Zimrri
// zgudino


#include <iostream>
#include <string>
using namespace std;

#include "video.h"
#include "vlist.h"

int main()
{	
	const int MAX =100;
	
	Video *videos[MAX];

	string title;
 	string url; 
	string comment; 
	double length;
	int rating;
	int size=0;
	
	string sort;
	
	cin >> sort;
	cin.ignore();

	Vlist list;

	if( (sort != "length")  && (sort != "print") && (sort != "title") && (sort != "insert") && (sort != "lookup"))
	{
	  cerr << sort << " is not a legal command, giving up.\n";
	  return 1;
	}
	
	while (getline (cin, title))
	{
		getline (cin, url);
		getline (cin, comment);
		cin >> length;
		cin >> rating;
		cin.ignore();
   
	videos[size] = new Video( title, url, comment, length, rating);
	size++;
	}
	if ((sort == "print"))
	{
	  list.print();
	}
	if ((sort == "length"))
	{
	for(int last = size-1; last > 0; last--)
	 for(int cur = 0; cur < last; cur++)
	  if((videos[cur+1]->longer(videos[cur])))
	   swap(videos[cur], videos[cur+1]);
	}
	 
	
	else if ((sort == "rating"))
	{
	for(int last = size-1; last >0; last--)
	 for(int cur = 0; cur < last; cur++)
	  if ((videos[cur+1]->largerRating(videos[cur])))
	   swap(videos[cur], videos[cur+1]);
	}
	

	else if (( sort == "title"))
	{
	for(int last = size-1; last >0;	last--)
	 for(int cur = 0; cur < last; cur++)
	  if ((videos[cur+1]->alphabetical(videos[cur])))
	   swap(videos[cur], videos[cur+1]);
	}
	
	
	for (int i = 0; i < size; i++)
	{

	(*videos[i]).print();

	}
return 0;
	
}
