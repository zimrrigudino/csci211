// video.cpp
// Gudino, Zimrri
// zgudino


#include <iostream>
#include <string>

#include "video.h"
Video::Video(string title, string url, string comment, double length, int rating)
{
	m_title = title;
	m_url = url;
	m_comment = comment;
	m_length = length;
	m_rating = rating;

}
bool Video::longer(Video *other)
{
	return m_length < other->m_length;
	
}

bool Video::largerRating(Video *other)
{
	return m_rating > other->m_rating;
	
}

bool Video::alphabetical(Video *other)
{
	return m_title < other-> m_title;
	
} 


void Video::print()
{
	

	cout << m_title << ", " << m_url << ", " << m_comment << ", " << m_length << ", ";
	while (m_rating > 0){
		cout << "*";
		m_rating--;}
	cout << endl;
}
