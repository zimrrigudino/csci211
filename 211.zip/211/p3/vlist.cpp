//vlist.cpp
#include <iostream>
#include <string>

#include "vlist.h"
#inlcude "video.h"
List::List()
{
    m_head = NULL;
}

void List::print()
{
	Node *ptr = m_head;
	while (ptr != NULL)
	{
	  cout << ptr->m_value<<endl;
	  ptr = ptr->m_next;
	}
}

List::~List()
{

    Node *ptr = m_head;
    while (ptr != NULL)
    {
        Node *temp;
        temp = ptr;
        ptr = ptr->m_next;
        delete temp;
    }
}

int List::sum()
{
	int total = 0;
	Node * ptr = m_head;
	while (ptr !=NULL)
	{
	total = ptr->m_value + total;
	ptr = ptr->m_next;
	}
	return total;
}
void List::insert(int value)
{
    m_head = new Node(value, m_head);
}

void List::insert_at_end(int value)
{
	if(m_head == NULL)
	{
	
	m_head = new Node(value, m_head);
	}
	else
	{
	  Node *ptr = m_head;
	  while (ptr->m_next != NULL)
	{
	  ptr = ptr->m_next;
	}
	  ptr->m_next = new Node (value, NULL);
	}

}
