//grid.cpp
// Gudino, Zimrri 
// zgudino


#include <iostream>
#include "grid.h"
using namespace std;

Grid::Grid ()
{
  for (int row = 0; row < 24; ++row)
  {
    for (int col = 0; col < 60; ++col)
      m_grid[row][col] = ' ';
  }
}

void
Grid::set (int x, int y, char c)
{
  m_char = c;
  if ((x < 0 || x > 59) || (y < 0 || y > 23));                    
  else
  {
    m_x = x;
    m_y = y;
    m_grid[m_y][m_x] = m_char;
  }
}

void
Grid::print () const 
{
  for (int row = 0; row < 24; ++row)
  {
    for (int col = 0; col < 60; ++col)
      cout << m_grid[row][col];
    cout << endl;
  }
}
