// point.cpp
// Gudino, Zimrri
// zgudino

#include <iostream> 
#include "point.h" 
using namespace std;

Point::Point(int x, int y, char c) : Shape(x,y)
{
 m_char = c;
}

void Point::draw(Grid &grid)
{
    grid.set(m_x, m_y, m_char);
}
