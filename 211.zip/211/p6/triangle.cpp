// triangle.cpp
// Gudino, Zimrri 
// zgduino

#include <iostream> 
#include "triangle.h" 

using namespace std; 

void Triangle::draw(Grid &grid) 
{
   for(int row = 0; row < 3; ++row) 
   { 
       for(int col = 0; col < 5; ++col) 
       { 
           if ((row == 0 && col == 2) || 
               (row == 1 && (col == 1 || col == 3)) || 
               (row == 2 && col < 5)) 
               grid.set(col + m_x, row + m_y, '+');
        }
    }
}  
