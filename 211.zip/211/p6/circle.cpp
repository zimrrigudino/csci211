//circle.cpp
// Gudino, Zimrri 
// zgduino

#include <iostream>
#include "circle.h"

using namespace std;

void Circle::draw(Grid &grid)
{
    for (int row = 0; row < 4; ++row)
    {
       for (int col = 0; col < 4; ++col)
       {
 	  if (((row == 0 || row == 3) && (col == 1 || col == 2)) ||
              ((row == 1 || row == 2) && (col == 0 || col == 3)))
              grid.set (col + m_x, row + m_y, 'o');
        }
      }
}
