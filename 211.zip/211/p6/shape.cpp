// shape.cpp
// Gudino, Zimrri 
// zgudino

#include <iostream>
#include "shape.h"
using namespace std;

Shape::Shape(int x, int y)
{
m_x = x;
m_y = y;
}

