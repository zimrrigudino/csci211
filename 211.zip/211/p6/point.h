// point.h
// Gudino, Zimrri 
// zgudino

#include <iostream>
#include "shape.h"

#ifndef POINT_H
#define POINT_H

using namespace std;
class Point: public Shape 
{
    public:
        Point(int x, int y, char c);

        void draw(Grid & grid);

    protected:
        char m_char;
};
#endif
