// circle.h
// Gudino, Zimrri 
// zgduino

#include <iostream> 
#include "shape.h"

#ifndef CIRCLE_H
#define CIRCLE_H

using namespace std;

class Circle: public Shape 
{
   public:
       Circle(int x, int y) : Shape(x, y) {}
       void draw(Grid &grid);
};
#endif 
