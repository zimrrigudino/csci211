// grid.h
// Gudino, Zimrri
// zgudino

#include <iostream>
using namespace std;

#ifndef GRID_H
#define GRID_H

class Grid
{
    public:        
        Grid();
        void set(int x, int y, char c);
        void print() const;

    private:
        int m_x;       
        int m_y;        
        char m_char;           
        char m_grid[24][60]; 
};
#endif
