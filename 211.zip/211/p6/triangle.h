// triangle.h
// Gudino, Zimrri 
// zgduino

#include "shape.h" 

#ifndef TRIANGLE_H 
#define TRIANGLE_H

using namespace std;

class Triangle: public Shape 
{
     public:

        Triangle(int x, int y) : Shape (x,y) {}
        void draw(Grid &grid);
};
#endif 
