//square.cpp
// Gudino, Zimrri 
// zgduino

#include <iostream>
#include "square.h"
using namespace std;

Square::Square(int x, int y, int size) : Shape(x, y) 
{
  m_size = size;
} 

void Square::draw(Grid &grid)
{
     for(int row = 0; row < m_size; ++row) 
     { 
         for(int col = 0; col < m_size; ++col) 
         { 
           if ((row == 0 || row == (m_size - 1)) || 
               (col == 0 || col == (m_size - 1)))
               grid.set(row + m_x, col + m_y, '*');
          }
       }
}

