// square.h
// Gudino, Zimrri 
// zgduino

#include <iostream>
#include "shape.h"

#ifndef SQUARE_H
#define SQUARE_H

using namespace std;

class Square: public Shape
{
   public: 
      Square(int x, int y, int size);
      void draw (Grid &grid);

   protected: 
      int m_size; 
};
#endif 
