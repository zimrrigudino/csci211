//path.cpp
//Gudino, Zimrri
//zgudino


#include <iostream>
#include <vector>
#include "location.h"
using namespace std;

int main()
{
  double longitude; 
  double latitude; 
  
  vector<Location*> location; 
  
  while (cin >> latitude) 
  { 
    cin >> longitude;
    location.push_back(new Location(latitude, longitude));
  }  
  for(unsigned i=0; i < location.size(); i++)
  { 
    location[i]->print(cout);
    cout << endl;
  }
return 0;
}
