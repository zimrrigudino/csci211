#include <iostream>

using namespace std;

int main(){

int var1, var2, add;
cin >> var1;
cin >> var2;
add = var1 + var2;
cout << var1 << " + " << var2 << " = " << add<< endl;
return 0;
}
