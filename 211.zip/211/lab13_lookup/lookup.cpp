#include <map>
#include <string>
#include <iostream>
#include "location.h"
using namespace std;

int main()
{
 double longitude;
 double latitude;
 string title;

 map<string, Location*> the_map;
 
 while (cin >> latitude)
 {
  if(latitude == 0)
  {
     break;
  }  
  cin >> longitude;
  cin >> title;
  the_map[title] = new Location(latitude,longitude); 
 } 
 
 while(cin >> title)
 {
   map<string, Location*>::iterator iter; 
   iter = the_map.find(title);
   if(iter == the_map.end())
   {
     cout << title << " not in database" << endl;
   }
   else 
   {
     cout << iter->first << " is at ";
     iter->second->print(cout);
     cout << endl;
   }
 }
 return 0;
}
 
