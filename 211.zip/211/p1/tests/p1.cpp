//Zimrri Gudino P1
#include <iostream>

using namespace std;

int main(){
	
	int array[100];

	int x;
	for (int i=0;i<=99;i++){
		cin >> x;
		if (x>0)
			array[i]=x;
		else
			while(i<=99){
				array[i]=0;
				i++;
				
	}
	}
	int high=array[0];
	for (int check=0;check<=99;check++){
		if(array[check]>high)
			 high=array[check];
	}
	for (int row=high;row>=1;row--){
		for(int colum=0; colum<= 99; colum++){
			if (array[colum]>0)			
				if(array[colum]>=row) cout << "*";
				else cout << " ";
	}
	cout << endl;
}
	return 0;
}
