//calc.cpp
//Gudino, Zimrri
// zgudino


#include <iostream>
#include <string>
#include <algorithm>
#include <cmath>
#include "dstack.h"
#include "ctype.h"
using namespace std;
void error()
{
	cerr << "Error: Invalid expression." << endl;
	exit(1);
}

int main()
{
	char oper;
	double value;
	Dstack stack;

	while (cin.peek() != EOF)
	{
		if (isspace(cin.peek()))
		{
			cin.ignore();
		}
		else if (isdigit(cin.peek()) || cin.peek() == '.')
		{
			if(!cin.good())
			{
				error();
			}
			cin >> value;
			stack.push(value);
			if(!isspace(cin.peek()) && !isprint(cin.peek()))
			{		
				error();
			}
			if (!isspace(cin.peek()) && cin.peek() == '.')
			{
				error();
			} 		
		}
		else
		{

			cin >> oper;
			double Rval;
			double Lval;
			if (stack.size() < 2)
			{
				error();
			}
			stack.pop(Rval);
			stack.pop(Lval);
			switch (oper)
			{
				case '+':
					{
						stack.push(Lval+Rval);
						break;
					}
				case '-':
					{
						stack.push(Lval-Rval);
						break;
					}
				case '*': 
					{
						stack.push(Lval*Rval);
						break;
					}
				case '/':
					{
						stack.push(Lval/Rval);
						break;
					}
				case '^':
					{
						if(Lval == 0 && Rval < 0)
							error();
						if( Lval < 0 && Rval == 0)
							error();

						stack.push(pow(Lval,Rval));
						break;
					}

			}
		}
	}
	double result;
	if (stack.size() == 1)
	{
		stack.pop(result);
		cout << result << endl;
	}
	else 
	{
		error();
	}
	return 0;
}

