// dstack.cpp
// Gudino, Zimrri 
// zgudino

#include <iostream> 
#include <string> 

#include "dstack.h"
int m_size = 0; 
Dstack::Dstack()
{
  m_head = NULL;
}
Dstack::~Dstack()
{
	Node *ptr = m_head;
	while (ptr != NULL)
	{
	   Node *temp;
	   temp = ptr;
	   ptr = ptr->m_next;
	   delete temp;
	 }
}
void Dstack::push(double value) 
{

m_head = new Node(value, m_head);
m_size++;

}
bool Dstack::pop(double &value)
{
 Node *ptr= m_head;
 if (ptr == NULL)
 {
 return false; 	
 }
 value = m_head->m_value;
 Node *temp = m_head;
 m_head = m_head->m_next;
 delete temp;
 m_size--;
 return true;
}
bool Dstack::empty()
{
return false;
}

int Dstack::size()
{
return m_size;
}
