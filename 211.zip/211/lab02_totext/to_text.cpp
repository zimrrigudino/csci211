#include <iostream>
using namespace std;

int main(){
int value;
for (int x = 0; x<=99; x++) {
	cin >> value; 
	switch (value)
	{
		case 0 : cout << "zero\n";
			value = -1;
			break;
		case 1 : cout << "one\n";
			value = -1;
		 	break;
		case 2 : cout << "two\n"; 
			value = -1;
			break;
		case 3 : cout << "three\n"; 
			value = -1;
			break;
		case 4 : cout << "four\n"; 
			value = -1;
			break;
		case 5 : cout << "five\n";
			value = -1;
			break;
		case 6 : cout << "six\n";
			value = -1;
			break;
		case 7 : cout << "seven\n";
			value = -1;
			break;
		case 8 : cout << "eight\n";
			value = -1;
			break;
			value = -1;
		case 9 : cout << "nine\n";
			value = -1;
			break;
}}
	return 0; 
}
