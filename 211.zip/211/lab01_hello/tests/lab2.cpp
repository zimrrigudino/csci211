#include <iostream>

using namespace std;

int main(){

int x,y; 
cin >> x;
y=0;
while ( x>0){
cout << y << " hello\n";
y++; 
x--;}
return 0;
}

