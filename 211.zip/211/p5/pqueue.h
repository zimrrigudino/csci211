// pqueue.h 
// Gudino, Zimrri
// zgudino
#ifndef PQUEUE_H
#define PQUEUE_H
#include "cust.h"
#include <iostream>
#include <string>

using namespace std;

class Pqueue
{
   public:
    Pqueue ();
    ~Pqueue ();
    Cust *dequeue();
    void enqueue(Cust *cust, int priority);
    bool empty ();
    int size ();
    int first_priority();
   private:
      class Node 
      {
       public:
         Node(Cust *cust, int priority, Node *next)
         {
           m_cust = cust;
           m_priority = priority;
           m_next = next;
         } 
        Cust *m_cust;
        int m_priority;
        Node *m_next;
      };
  Node *m_head;
};
#endif
