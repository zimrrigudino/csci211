//cust.cpp
//Gudino, Zimrri
// zgudino

#include <iostream>
#include <string> 
#include "cust.h"
#include <assert.h>
using namespace std;

Cust::Cust (string name, bool type, int time, int items)
{
	m_name = name;
	m_time = time;
	m_type = type;
	m_items = items;
}
void Cust::print(ostream &os)
{

	string rob_shop;
	if (m_type == true)
	{
		rob_shop = "robber";
	}
	else 
	{
		rob_shop = "shopper";
	}

	os << m_name << " " << rob_shop << " " <<  m_time << " " <<  m_items << endl;  
}


void Cust::print_done_shopping(ostream &os, int clock)
{
	m_time = clock;
	os << clock << ": " << m_name << " done shopping" << endl;
}

void Cust::print_start_time(ostream &os, int clock)
{
	assert(clock == m_time);
	os << clock << ": " << m_name << " entered store" << endl;
}

void Cust::print_start_checkout(ostream &os, int clock, int i)
{
	if (m_type != true)
	{//shopper
		os << clock << ": " << m_name <<" started checkout with checker " << i << endl;
	}
	else 
	{ 
		os << clock << ": " << m_name <<" started checkout with checker " << i << endl;
	}
}

int Cust::get_items()
{
	return m_items;
}

bool Cust::get_type()
{ 

	if(m_type == true) 
	{
		return true;
	}
	else
	{ 
		return false;
	}
}

void Cust::print_done_checkout(ostream &os, int clock, int num_checker, int money_convert)
{
	if(m_items > 1)
	{
		if(m_type == true)
		{
			os << clock << ": " << m_name << " stole $" << money_convert << " and " << m_items << " items from checker " << num_checker << endl;
			money_convert = 0;
		}

		else
		{
			os << clock << ": " << m_name << " paid $" << (m_items *3) << " for " <<m_items<< " items to checker " << num_checker << endl;
		}
	}
	else 
	{ 
		if(m_type == true)
		{
			os << clock << ": " << m_name << " stole $" << money_convert << " and " << m_items << " item from checker " << num_checker << endl;
			money_convert = 0;
		}
		else
		{
			os << clock << ": " << m_name << " paid $" << (m_items *3) << " for " <<m_items<< " item to checker " << num_checker << endl;
		}
	}
}



