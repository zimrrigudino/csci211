// sim.cpp
// Gudino, Zimrri
// zgudino

#include<iostream>
#include<fstream>
#include<string>
#include<assert.h>
#include<stdio.h>
#include<stdlib.h>
#include "cust.h"
#include "pqueue.h"
#include "ctype.h" 
using namespace std;

struct Checker
{
	int money = 0;
	int av_time =0;
	int time_break = 0;
	Cust *customer;
};

bool legal_int(char *str)
{
	while(*str != NULL)
	{ 
		if(!isdigit(*str))
			return false;
		str++;
	} 
	return true;
}

void run_simulation(Pqueue &arrival_q, int num_checkers, int break_time, ostream &os)
{
	int num_customers = arrival_q.size();
	Checker *checker = new Checker[num_checkers];
	Pqueue shopping_q;
	Pqueue checker_q;
	int clock = 1;

	for (int i=0; i < num_checkers; i++)
	{  
		checker[i].money = 100;  
		checker[i].av_time = 0;
		checker[i].customer = NULL;
	}

	for (clock = 1; num_customers > 0;  clock++)
	{       //part 1
		while(!arrival_q.empty() && arrival_q.first_priority() == clock)
		{ 
			Cust *cust;
			cust = arrival_q.dequeue();
			shopping_q.enqueue(cust, cust->done_shopping_time());
			cust->print_start_time(os, clock);
			os << "inside store time: " << clock << "prio: " << shopping_q.first_priority() << endl;

		}
		while(!shopping_q.empty() && shopping_q.first_priority() == clock)
		{ //part 2
			Cust *cust2;
			cust2 = shopping_q.dequeue();
			checker_q.enqueue(cust2, 1);
			cust2->print_done_shopping(os, clock);
		}
		for (int i = 0; i < num_checkers; i++)
		{     //part 3 

			if(checker[i].customer != NULL && checker[i].av_time == 0 /*&& !checker_q.empty()*/)
			{ 

				if(checker[i].customer->get_type() == true/* && checker[i].av_time == clock*/)
				{// robber 
					checker[i].customer->print_done_checkout(os, clock, i, checker[i].money);
					checker[i].money = 0;
					checker[i].av_time += break_time;
				}
				else
				{
					checker[i].money += (checker[i].customer->get_items() * 3);
					checker[i].customer->print_done_checkout(os, clock, i, checker[i].money);

				}
				Cust *tmp;   	
				tmp = checker[i].customer;
				delete tmp;
				checker[i].customer = NULL;
				num_customers--;
			}        
		}

		for (int i = 0; i < num_checkers; i++)
		{ // part 4 
			if (checker[i].customer == NULL && checker[i].av_time == 0 && !checker_q.empty())
			{
				checker[i].customer = checker_q.dequeue();
				checker[i].customer->print_start_checkout(os, clock, i);
				if(checker[i].customer->get_type() == true){
					checker[i].av_time = 4;	
				} else {
					checker[i].av_time = checker[i].customer->get_items();
				}
			}
		}
		for (int i = 0; i < num_checkers; i++)
		{
			if(checker[i].av_time > 0)
			{
				checker[i].av_time -= 1;
			}
		}
	} 
	for( int i=0; i < num_checkers; i++)
	{
		os << "registers[" << i << "] = $" << checker[i].money << endl;
	}
	os << "time = " << clock << endl;
}

int main (int argc, char *argv[])
{
	int items = 0; 
	string name;
	string robber;
	Pqueue arrival_q; 


	if(argc != 5) 
	{
		cerr << "Error: invalid number of command line arguments.\n";
		return 1;
	}

	ifstream inFile(argv[3], ios::in);
	if (!inFile)
	{
		cerr << "Error: could not open input file <" << argv[3] << ">.\n";
		return 1;
	}

	if((legal_int(argv[1])) == false || atoi(argv[1]) < 1)  
	{
		cerr << "Error: invalid number of checkers specified.\n";
		return 1;
	}

	if((legal_int(argv[2])) == false || atoi(argv[2]) < 0)          
	{
		cerr << "Error: invalid checker break duration specified.\n";
		return 1;
	}

	ofstream outFile(argv[4], ios::out);
	if (!outFile)
	{ 
		cerr << "Error: could not open output file <" << argv[4] << ">.\n";
		return 1;
	}


	while (inFile >> name)
	{
		int arrival_time;
		inFile >> robber; 
		inFile >> arrival_time; 
		inFile >> items;
		Cust *temp = new Cust(name, (robber == "robber" ? true: false), arrival_time, items);
		arrival_q.enqueue(temp, arrival_time);

	} 

	run_simulation(arrival_q, atoi(argv[1]), atoi(argv[2]), outFile);

	return 0;
}

