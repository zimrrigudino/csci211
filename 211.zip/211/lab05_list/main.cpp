#include <iostream>
using namespace std;
#include "list.h"

int main()
{
    // instantiate a List class (the constructor takes NO arguments)
    List list;
    int num_line;
    while (cin >> num_line){
	list.insert_at_end(num_line);
    }	
    list.print();
    cout << "sum = " << list.sum()  <<endl;
    // NOTE:
    // List list();  is incorrect, when there are no arguments don't use ()

    // insert rs into the list
    /*list.print();
    list.insert(1);
    list.print();
    list.insert(2);
    list.print();
    list.insert(3);
    list.print();*/

    return 0;
}
