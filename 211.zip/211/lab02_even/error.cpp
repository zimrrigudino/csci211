#include <iostream>
using namespace std;

int main()
{
    // write to standard output
    cout << "written to standard output" << endl;

    // write to standard error
   cerr << "written to standard error" << endl;

    // return 0 from main() if there are no errors
    return 0;
} 
