#include <iostream>
using namespace std;

int main(){
int even_check, value;
bool even = true;
while (cin >> value) {
	
	even_check=value%2;
	if (even_check != 0)
		even = false;
}
	if (even == true){
		cout<<"all even\n";
		return 0; 
}	
	else{
		cerr<<"not all even\n";
		return 1; 
}}
