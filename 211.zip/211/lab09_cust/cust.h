// cust.h
// Gudino, Zimrri
// zgudino
#ifndef CUST_H
#define CUST_H
#include <iostream>
#include <string> 

using namespace std;

class Cust
{
public: 
    Cust (string name, bool type, int time, int items);
    void print (ostream &os);
private:
    string m_name;
    bool m_type;
    int m_time;
    int m_items;
    int m_stolen;
};
#endif 
