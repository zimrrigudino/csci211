//cust.cpp
//Gudino, Zimrri
// zgudino

#include <iostream>
#include <string> 
#include "cust.h"

using namespace std;

Cust::Cust (string name, bool type, int time, int items)
{
  m_name = name;
  m_time = time;
  m_type = type;
  m_items = items;
}
void Cust::print(ostream &os)
{

  string rob_shop;
  if (m_type == true)
  {
  rob_shop = "robber";
  }
  else 
  {
  rob_shop = "shopper";
  }
  
os << m_name << " " << rob_shop << " " <<  m_time << " " <<  m_items << endl;  
}

