
#ifndef COURSE_H
#define COURSE_H
#include <iostream>
#include <string>


using namespace std;

class School
{
    public:
	School(string name, int number, int time);
	
	void print();
        
    private:
	string m_name;
	int m_number;
	int m_time;

}; 

#endif
