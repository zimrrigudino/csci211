#include <iostream>
#include <string>

#include "course.h"

School::School(string name, int number, int time)
{
	m_name = name;
	m_number = number;
	m_time = time;

}

void School::print()
{
	cout << m_name << " " << m_number << " at " << m_time << endl;
}
