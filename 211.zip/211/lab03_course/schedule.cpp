#include <iostream>
#include <string>

#include "course.h"

using namespace std;

int main()
{
	School programming("CSCI", 211, 1000);
	School english("ENGL", 130, 1400);
	School physics("PHYS", 204, 800);

	programming.print();
	english.print();
	physics.print();
	


	return 0;
}
   

