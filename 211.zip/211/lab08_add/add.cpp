#include <iostream>
#include "ctype.h"
#include "stdlib.h"
using namespace std;

bool legal_int(char *str)
{
	while(*str != NULL) 
	{
		if(!isdigit(*str))
		{
		
			return false;
		}
		else 
		{
			str++;
		}
	}
	return true;

}


int main(int argc, char *argv[])
{
	int total = 0;
	if( argc < 2)
	{
		cerr << "Error: illegal integer." << endl;
		return 1;
	}
	for(int a = 1; a < argc; a++)
	{
		if (legal_int(argv[a]) == false) 
		{
			cerr << "Error: illegal integer." << endl;
			return 1;
			break; 
		}
		else
		{ 
			int value = atoi(argv[a]);
			total += value; 
		}
	}
	cout << total << endl;
	return 0; 
}
