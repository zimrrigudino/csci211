//bst.h 
// Gudino, Zimrri 
// zgudino

#ifndef BST_H
#define BST_H
#include <iostream> 
#include <string> 
#include <vector> 
#include <queue>

using namespace std;

class Tree
{
	public:
		Tree() {m_root=NULL;}
		// ~Tree();
                bool insertVector(string value); 
		bool lookup(string target);
		bool insert(string value);
 		bool isBalance()
  		{
			return isBalance(m_root);
 		}
		int max(int a, int b);
		int size(){return m_size;}   
		void printVector(vector<string> &value);
		void print(vector<string> &value)
		{
			print(m_root, value);
		} 
		void breadth(vector<string> &value) 
		{
			queue<Node*> q;
			q.push(m_root);
			breadth(q, value);
		}  
                double distance()
		{
                    if(m_size == 0) 
                    {
                    return 0;
                    }
                    else 
                    {
		    double sum = distance(m_root,0);
                    return sum / m_size;
                    }
 		}
 		
                void depth(vector <string> &string)
                {
                     return depth(m_root, string);
                }
		
	private:
		class Node 
		{
			public:
				Node(string value)
				{
					m_value = value;
					m_left = NULL;
					m_right = NULL;
				}
				string m_value;
				Node* m_left;
				Node* m_right;
		};
		Node* m_root;
		bool insert(string value, Node* cur_root);
		int m_size =0;
		bool lookup(string target, Node* cur_root); 
		void print(Node* ptr, vector<string> &value);
		void breadth(queue<Node*> &q, vector<string> &value);
		//int maxDepth(struct Tree *m_node)
		int height(Node *ptr);
		bool isBalance(Node *ptr);
		int distance(Node *cur_root, int level);
  		void depth(Node *cur_root, vector <string> &string);
                void reinsert (vector <string> &string, int start, int end);
                bool insertVector(string value, Node* cur_root);
};
#endif
