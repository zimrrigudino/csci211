//bst.cpp 
// Gudino, Zimrri
// zgudino

#include <iostream> 
#include <string>
#include <vector> 
#include <cstdlib>
#include <queue>
#include <cmath>
#include "bst.h"

using namespace std;

bool Tree::insert(string value) // public
{ 
	return insert(value, m_root);
}
bool Tree::insert(string value, Node* cur_root) // private
{
	if(m_root == NULL)
	{
		m_root = new Node(value);
		m_size++; 
		return true; 
	}
	else if (value < cur_root->m_value)
	{	
		if( cur_root->m_left != NULL)
		{
			insert(value, cur_root->m_left);
		}
		else
		{
			cur_root->m_left = new Node(value);
			m_size++; 
			return true;
		}
	}
	else if (value > cur_root->m_value)
	{	
		if( cur_root->m_right != NULL)
		{
			insert(value, cur_root->m_right);
		}
		else
		{
			cur_root->m_right = new Node(value);
			m_size++; 
			return true;
		}
	}
	else 
	{
		cerr << "insert <" << value << "> failed. String already in tree.\n";
		return false;
	}
 return false;
}


void Tree::print(Node* ptr, vector<string> &value)
{
	if(ptr != NULL)
	{
		if(ptr->m_left != NULL)
		{
			print(ptr->m_left, value);
		}
		value.push_back(ptr->m_value);
		if(ptr->m_right != NULL)
		{
			print(ptr->m_right, value);
		}
	}
}

bool Tree::lookup(string target)
{
	if(m_root == NULL)
	{
		return false;
	}
	else 
	{
		return lookup(target, m_root);
	}
   return false;
}
bool Tree::lookup(string target,Node* cur_root)
{
	if (cur_root == NULL)
	{
		return false;
	}
	if(cur_root->m_value == target)
	{
		return true;
	}
	if (target < cur_root->m_value)
	{
		return lookup(target, cur_root->m_left);
	}
	else if (target > cur_root->m_value)
	{
		return lookup(target, cur_root->m_right);
	}
   return false;
} 
  void Tree::breadth(queue<Node*> &q, vector<string> &value)
  { 
  	while(!q.empty())
  	{
  		if(q.front()->m_left!=NULL)
  		{
  			q.push(q.front()->m_left);
  		}
  		if(q.front()->m_right!=NULL)
  		{
  			q.push(q.front()->m_right);
  		}
  		string temp;
  		Node *ptr = q.front();
  		temp = ptr->m_value;
  		q.pop();
  		value.push_back(temp);
  	}
  }

bool Tree::isBalance(Node *ptr)
{
  if (ptr == NULL)
  {
      return true;
  }
  int l = height(ptr->m_left);
  int r = height (ptr->m_right);
  
  if (abs(l-r) <= 1 && isBalance(ptr->m_left) && isBalance(ptr->m_right))
  { 
    return true;
  }
  else 
  {
   return false; 
  }
}

int Tree::max(int a, int b)
{
   return (a >=b) ? a: b;
}

int Tree::height(Node *ptr)
{
	if(ptr == NULL)
	{
		return 0;
	}
	return 1 + max(height(ptr->m_left), height(ptr->m_right));
}

int Tree::distance(Node *cur_root, int level)
{
  if(cur_root == NULL)
  {
   return 0;
  }
  return level + distance(cur_root->m_left, level+1) + distance(cur_root->m_right, level+1);
}



