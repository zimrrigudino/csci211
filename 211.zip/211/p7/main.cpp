//main.cpp
//Gudino, Zimrri 
// zgudino

#include <iostream>
#include <string>
#include <vector> 
#include <cstdlib>
#include <queue>
#include "bst.h"
#include "ctype.h"
using namespace std;

int main() 
{ 
	Tree myTree;
	vector<string> myVector;

	string str;
	string cmd;
	

	while(cin >>cmd)
	{ 
		if((cmd != "find") && (cmd != "print") && (cmd != "echo") && (cmd != "insert") && (cmd != "size") && (cmd != "breadth")&& (cmd != "distance") && (cmd != "balanced")&& (cmd != "rebalance"))
		{
			cerr << "Illegal command <" << cmd << ">.\n";
			getline(cin,str);
			//return 1;
		}
		if(cmd == "insert")
		{ while(isspace(cin.peek()))
			{
				cin.ignore();
			}
			getline(cin,str);
			//myVector.push_back(str);
			myTree.insert(str);
			/*if (myTree.insert(str) == false) 
			   {
			   cerr << "insert <" << str << "> failed. String already in tree.\n";
			   }*/ 

		}
		if(cmd == "print")
		{ 
			vector <string> value;
			myTree.print(value);
			//myTree.printVector(value); 
			cout << "{";
			for(unsigned int i = 0; i < value.size(); i++)
			{
			if(i != 0)
			{
				cout << ", ";
			}
				cout << value[i];   
			//myTree.PrintInOrder();
			//cout << "\n";
		}
		if(cmd == "echo")
		{ 
			while(isspace(cin.peek()))
			{
				cin.ignore();
			}
			getline(cin,str);
			cout << str << endl;
		}
		if(cmd == "size")
		{
			cout << myTree.size() << endl;
		}
		if(cmd == "find")
		{
			while(isspace(cin.peek()))
			{
				cin.ignore();
			}
			getline(cin,str);
			if ( myTree.lookup(str) == true)
			{
				cout << "<" << str << "> is in tree." << endl;
			}
			else if (myTree.lookup(str) == false)
			{
				cout << "<" << str << "> is not in tree." << endl;
			}
		}
		if(cmd == "breadth")
		{
 			vector <string> value;
			myTree.breadth(value);
			//myTree.printVector(value); 
			cout << "{";
			for(unsigned int i = 0; i < value.size(); i++)
			{
			if(i != 0)
			{
				cout << ", ";
			}
				cout << value[i];
		}
	cout << "}" << endl;
		}
		if(cmd == "balanced")
		{     
 			if (myTree.isBalance() == true)
 			{
			cout << "Tree is balanced." << endl;
	     		}
			else
			{
			cout << "Tree is not balanced." << endl;
			}
		}  
		if(cmd == "rebalance")
		{
		       
		}
		if(cmd == "distance")
		{  
                   cout << "Average distance of nodes to root = " << myTree.distance() << endl;
		}
	}


	return 0;
}
