// pqueue.cpp
// Gudino, Zimrri
// zgudino
#include<iostream>
#include<string>
#include "pqueue.h"
#include "cust.h"
using namespace std;
Pqueue::Pqueue ()
{ 
  m_head = NULL; 
}
Pqueue::~Pqueue ()
{
  Node *ptr = m_head;

  while (ptr != NULL)
  {
    Node *tmp;                  
    tmp = ptr;
    ptr = ptr->m_next;          
    delete tmp;             
  }
}

void Pqueue::enqueue (Cust * customer, int priority)
{
  if (m_head == NULL || priority < m_head->m_priority)
  {
    m_head = new Node (customer, priority, m_head);
  }
  else
  {
    Node *ptr = m_head;
    while (ptr->m_next != NULL && priority >= ptr->m_next->m_priority)
    {
      ptr = ptr->m_next;
    }
    ptr->m_next = new Node (customer, priority, ptr->m_next);
  }
}

Cust *Pqueue::dequeue ()
{
  if (m_head == NULL)
  {
    return NULL;
  }

  else
  {
   
    Node *ptr = m_head;
    Cust *cust = ptr->m_cust;
    m_head = m_head->m_next;
    delete ptr;
    return cust;
  }
}
bool Pqueue::empty ()
{
 if(m_head == NULL)
 {
 return true;
 }
 else
 {
 return false;
 }
}
